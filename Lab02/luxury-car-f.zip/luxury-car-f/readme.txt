The original .max file is at http://www.cadnav.com/3d-models/model-28496.html which includes larger texture map for body. I had to reduce the size because some of my 3d apps would not handle images larger than 1024 x 1024. Also I regrouped by material and rotated model.

Texture map70bodyw-alt.jpg is an inverted version of 70bodyw.jpg because some 3d app use the reverse for opacity/transparency map. In your 3d app use the one that makes windows semi-transparent. See the .mtl file to see what needs to change. I seem to have lost this in the .3ds but it is easy to add back.

In the original it is label a muscle car but it is really a luxury car from the 70s. Not sure which make or model.

Enjoy.

